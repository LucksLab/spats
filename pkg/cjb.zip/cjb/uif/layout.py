
class Point(object):

    def __init__(self, x = 0, y = 0):
        self.x = x
        self.y = y

    def add(self, pt):
        return Point(self.x + pt.x, self.y + pt.y)
    # etc...

class Size(object):

    def __init__(self, w = 0, h = 0):
        self.w = w
        self.h = h

    @property
    def width(self):
        return self.w

    @property
    def height(self):
        return self.h

    def scale(self, factor):
        return Size(factor * self.w, factor * self.h)


class Rect(object):

    def __init__(self, x = 0, y = 0, w = 0, h = 0, origin = None, center = None, size = None):
        self.size = size or Size(w, h)
        self.origin = origin or (Point(center.x - 0.5 * size.width, center.y - 0.5 * size.h) if center else Point(x, y))
        self.leftover = None

    def copy(self):
        return Rect(x = self.origin.x, y = self.origin.y, w = self.size.w, h = self.size.h)

    def bounds(self):
        return Rect(size = self.size)

    @property
    def left(self):
        return self.origin.x

    @property
    def right(self):
        return self.origin.x + self.size.w

    @property
    def top(self):
        return self.origin.y

    @property
    def bottom(self):
        return self.origin.y + self.size.h

    def array(self):
        return [ self.origin.x, self.origin.y, self.size.w, self.size.h ]

    def add(self, x = 0, y = 0, point = None):
        p = point or Point(x,y)
        return Rect(p.x + self.origin.x, p.y + self.origin.y, size = self.size)

    def update(self, x = 0, y = 0, w = 0, h = 0, origin = None, center = None, size = None):
        self.size = size or Size(w, h)
        self.origin = origin or (Point(center.x - 0.5 * size.width, center.y - 0.5 * size.h) if center else Point(x, y))
        
    def center(self):
        return Point(self.origin.x + 0.5 * self.size.w, self.origin.y + 0.5 * self.size.h)

    def inset(self, w = None, h = None):
        h = h or w
        return Rect(self.origin.x + w, self.origin.y + h, self.size.w - 2 * w, self.size.h - 2 * h)

    def centeredSubrect(self, w = None, h = None, size = None):
        sz = size or Size(w, h)
        return Rect(self.origin.x + 0.5 * (self.size.w - sz.w), self.origin.y + 0.5 * (self.size.h - sz.h), size = sz)

    def leftSubrect(self, w, margin = 0):
        self.leftover = Rect(self.origin.x + w + margin, self.origin.y, self.size.w - w - margin, self.size.h)
        return Rect(self.origin.x + margin, self.origin.y, w, self.size.h)

    def leftCenteredSubrect(self, w = None, h = None, size = None, margin = 0):
        sz = size or Size(w, h)
        self.leftover = Rect(self.origin.x + sz.w + margin, self.origin.y, self.size.w - sz.w - margin, self.size.h)
        return Rect(self.origin.x + margin, self.origin.y + 0.5 * (self.size.h - sz.h), size = sz)

    def topLeftSubrect(self, w = None, h = None, size = None, margins = None, margin = 0):
        m = margins or Size(margin, margin)
        sz = size or Size(w, h)
        self.leftover = Rect(self.origin.x + m.w + sz.w, self.origin.y + m.h + sz.h, self.size.w - m.w - sz.w, self.size.h - m.h - sz.h)
        return Rect(self.origin.x + m.w, self.origin.y + m.h, size = sz)

    def topSubrect(self, h, margin = 0):
        self.leftover = Rect(self.origin.x, self.origin.y + h + margin, self.size.w, self.size.h - h - margin)
        return Rect(self.origin.x, self.origin.y + margin, self.size.w, h)

    def topCenteredSubrect(self, w = None, h = None, size = None, margin = 0):
        sz = size or Size(w, h)
        self.leftover = Rect(self.origin.x, self.origin.y + sz.h + margin, self.size.w, self.size.h - sz.h - margin)
        return Rect(self.origin.x + 0.5 * (self.size.w - sz.w), self.origin.y + margin, size = sz)

    def topRightSubrect(self, w = None, h = None, size = None, margins = None, margin = 0):
        m = margins or Size(margin, margin)
        sz = size or Size(w, h)
        self.leftover = Rect(self.origin.x, self.origin.y + sz.w + m.w, w = self.size.w - m.w - sz.w, h = self.size.h - m.h - sz.h)
        return Rect(self.right - m.w - sz.w, self.origin.y + m.h, size = sz)

    def rightSubrect(self, w, margin = 0):
        self.leftover = Rect(origin = self.origin, w = self.size.w - w - margin, h = self.size.h)
        return Rect(self.right - margin - w, self.origin.y, w, self.size.h)

    def rightCenteredSubrect(self, w = None, h = None, size = None, margin = 0):
        sz = size or Size(w, h)
        self.leftover = Rect(origin = self.origin, w = self.size.w - sz.w - margin, h = self.size.h)
        return Rect(self.right - margin - sz.w, self.origin.y + 0.5 * (self.size.h - sz.h), size = sz)

    #...

    def bottomRightSubrect(self, w = None, h = None, size = None, margins = None, margin = 0):
        m = margins or Size(margin, margin)
        sz = size or Size(w, h)
        self.leftover = Rect(origin = self.origin, w = self.size.w - m.w - sz.w, h = self.size.h - m.h - sz.h)
        return Rect(self.right - m.w - sz.w, self.bottom - m.h - sz.h, size = sz)

    def bottomSubrect(self, h, margin = 0):
        self.leftover = Rect(self.origin.x, self.origin.y, self.size.w, self.size.h - h - margin)
        return Rect(self.origin.x, self.bottom - h - margin, self.size.w, h)

    def bottomCenteredSubrect(self, w = None, h = None, size = None, margin = 0):
        sz = size or Size(w, h)
        self.leftover = Rect(origin = self.origin, w = self.size.w, h = self.size.h - sz.h - margin)
        return Rect(self.origin.x + 0.5 * (self.size.w - sz.w), self.bottom - sz.h - margin, size = sz)

    #...

    def fullSubrect(self):
        return self

    def layout(self, obj, layoutType, ret = 'self', **kwargs):
        frame = getattr(self, layoutType + 'Subrect')(**kwargs)
        if obj:
            obj.frame = frame
        return { 'self' : self,
                 'frame' : frame,
                 'leftover' : self.leftover }[ret]

class Margins(object):

    def __init__(self, top = 0, left = 0, bottom = 0, right = 0):
        self.top = top
        self.left = left
        self.bottom = bottom
        self.right = right


class Grid(object):

    def __init__(self, frame, itemSize, columns, rows, spacing = Size(), margins = Margins()):
        rowWidth = (itemSize.w + spacing.w) * columns - spacing.w + margins.left + margins.right
        colHeight = (itemSize.h + spacing.h) * rows - spacing.h + margins.top + margins.bottom
        self.start = Point(frame.origin.x + margins.left + 0.5 * (frame.size.w - rowWidth),
                           frame.origin.y + margins.top + 0.5 * (frame.size.h - colHeight))
        self.itemSize = itemSize
        self.columns = columns
        self.rows = rows
        self.spacing = spacing
        self.curIndex = 0

    def frame(self, index, length = 1):
        i = index % self.columns
        j = (index - i) / self.columns
        return Rect(self.start.x + i * (self.itemSize.w + self.spacing.w),
                    self.start.y + j * (self.itemSize.h + self.spacing.h),
                    self.itemSize.w * length,
                    self.itemSize.h)

    def setLocation(self, column, row, index = 0):
        self.curIndex = index or (row * self.columns) + column

    def nextFrame(self):
        index = self.curIndex
        self.curIndex += 1
        return self.frame(index)

    def applyToViews(self, views):
        idx = self.curIndex
        for i in range(len(views)):
            views[i].frame = self.frame(i + idx)
        self.curIndex = idx + len(views)

def divideWithSpacing(whole, numParts, spacing = 0):
    return (whole - (numParts - 1.0) * spacing) / n

def multiplyWithSpacing(part, numParts, spacing = 0, spaceOnEnds = False):
    return numParts * part + spacing * (numParts + (1 if spaceOnEnds else -1))

def layoutInScroller(views, frame, itemSize, margin = 0, scroller = None):
    from cjb.uif.views import Scroller
    if 0 == len(views):
        return None
    if scroller:
        container = scroller
    else:
        container = Scroller()
        parent = views[0].parent
        parent.addSubview(container)
    container.frame = frame
    cur = frame.bounds()
    for v in views:
        v.frame = cur.topCenteredSubrect(size = itemSize, margin = margin)
        container.addSubview(v)
        cur = cur.leftover
    return container
