
import copy
from cjb.uif.layout import Rect
import cjb.util.parse


def parseModel(scene, model):
    return dictParse(scene, cjb.util.parse.hierarchyParse(model), None)

def viewFactory(typeStr):
    return { 'c' : View,
             'b' : Button,
             'l' : Label,
             'tf' : TextField,
             'sv' : Scroller }[typeStr]()

def dictParse(scene, info, host):
    view = viewFactory(info['type'])
    host = host or view
    for key, value in info.iteritems():
        if key in [ 'type', 'children' ]:
            continue
        if key == 'bg':
            value = [ v.strip() for v in value.split(' ') if len(v.strip()) > 0 ]
        elif key == 'name':
            host.modelViews[value] = view
        setattr(view, key, value)
        view.dictParse(scene, info)
    for c in info.get('children', []):
        view.addSubview(dictParse(scene, c, host))
    return view

class View(object):

    def __init__(self, obj = None):
        self.viewId = None
        self.obj = obj
        self._target = None
        self.parent = None
        self.subviews = []
        self.frame = Rect()
        self.properties = {}
        self.modelViews = {}

    def dictParse(self, scene, info):
        pass

    def model(self, key):
        return self.modelViews[key]

    def addSubview(self, view, above = None, below = None):
        if view.parent:
            view.removeFromSuperview()
        view.parent = self
        if above or below:
            try:
                index = self.subviews.index(above or below)
                if above:
                    index = index + 1
            except:
                index = 0 if above else len(self.subviews)
            self.subviews.insert(index, view)
        else:
            self.subviews.append(view)
        return view

    def removeFromSuperview(self):
        if self.parent:
            self.parent.subviews.remove(self)
            self.parent = None

    def recursiveSubviews(self, svlist = None):
        if not svlist:
            svlist = []
        for sv in self.subviews:
            svlist.append(sv)
            sv.recursiveSubviews(svlist)
        return svlist

    @property
    def target(self):
        return self._target

    @target.setter
    def target(self, value):
        self._target = value

    @property
    def click(self):
        return self.properties.get('click', 0)

    @click.setter
    def click(self, value):
        self.properties['click'] = value

    @property
    def hidden(self):
        return (self.properties.get('hidden', 0) == 1)

    @hidden.setter
    def hidden(self, value):
        self.properties['hidden'] = (1 if value else 0)

    @property
    def bg(self):
        return self.properties.get('bg')

    @bg.setter
    def bg(self, value):
        self.properties['bg'] = value

    @property
    def alpha(self):
        return self.properties.get('alpha', 1.0)

    @alpha.setter
    def alpha(self, alpha):
        self.properties['alpha'] = alpha

    @property
    def text(self):
        return self.properties.get('text')

    @text.setter
    def text(self, value):
        if value != None:
            self.properties['text'] = value
        elif 'text' in self.properties:
            del(self.properties['text'])

    @property
    def alignment(self):
        return self.properties.get('alignment')

    @alignment.setter
    def alignment(self, value):
        self.properties['alignment'] = value

    @property
    def fontSize(self):
        return self.properties.get('fontSize', 1.0)

    @fontSize.setter
    def fontSize(self, fontSize):
        self.properties['fontSize'] = fontSize

    # ~private
    @property
    def viewType(self):
        return 'c'

    def dictionary(self):
        d = copy.copy(self.properties)
        d['type'] = self.viewType
        d['f'] = self.frame.array()
        if self.viewId:
            d['id'] = self.viewId
        for key, value in self.properties.iteritems():
            d[key] = value
        if 0 < len(self.subviews):
            d['c'] = [ v.dictionary() for v in self.subviews ]
        return d


class Scroller(View):

    @property
    def viewType(self):
        return 'sv'


class Button(View):

    def __init__(self, target = None, key = None, text = None, obj = None):
        View.__init__(self, obj)
        self._target = target
        self.key = key or (target.__name__ if target else None)
        self.text = text or self.key or getattr(obj, "displayName", None)

    def dictParse(self, scene, info):
        name = info.get('name')
        if name and hasattr(scene, name):
            self.target = getattr(scene, name)
        if not self.text:
            self.text = name
        scene.addView(self)

    @property
    def target(self):
        return self._target

    @target.setter
    def target(self, value):
        self._target = value
        self.key = self.key or value.__name__

    @property
    def viewType(self):
        return 'b'

    @property
    def key(self):
        return self.properties.get('key')

    @key.setter
    def key(self, value):
        self.properties['key'] = value

    @property
    def sideSpacing(self):
        return self.properties.get('sideSpacing')

    @sideSpacing.setter
    def sideSpacing(self, value):
        self.properties['sideSpacing'] = value


class Label(View):

    def __init__(self, text = None, fontSize = None, bg = None, obj = None):
        View.__init__(self, obj = obj)
        if text:
            self.text = text
        elif obj:
            try:
                self.text = obj.displayName
            except:
                pass
        if bg:
            self.bg = bg
        self.fontSize = fontSize or 12

    @property
    def viewType(self):
        return 'l'


class TextField(View):

    def __init__(self, target = None):
        View.__init__(self, None)
        self.target = target

    def dictParse(self, scene, info):
        name = info.get('name')
        if name and hasattr(scene, name):
            self.target = getattr(scene, name)
        scene.addView(self)

    @property
    def viewType(self):
        return 'tf'
