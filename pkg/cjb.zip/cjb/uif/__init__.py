
import json

from cjb.uif.layout import Size, Rect
from cjb.uif.views import Button, View, parseModel
import cjb.util.server



class Producer(object):

    def __init__(self):
        self.manager = None

    def sendMessage(self, message, scene):
        self.manager.sendMessageFromProducer(message, scene)

    def start(self):
        pass

    def handleMessage(self, payload):
        pass


class SceneProducer(Producer):

    def __init__(self, manager):
        Producer.__init__(self)
        self.manager = manager
        self.screenSize = None

    def sendScene(self, scene):
        if not self.screenSize or not scene.container:
            return
        scene.container.frame = Rect(size = self.screenSize)
        print("producer sending: " + scene.key)
        self.sendMessage(scene.container, scene)

    def handleMessage(self, payload):
        if "ui" in payload and "load" == payload["ui"]:
            self.screenSize = Size(payload["size"]["w"], payload["size"]["h"])
            self.manager.sendScenes()
        else:
            self.manager.handleViewMessage(payload)


class Filter(object):

    def filterView(self, view, scene):
        return view

    def keyedFilterView(self, view, scene, optional = False, default = None):
        key = scene.key
        handler = getattr(self, key, None) or getattr(self, key[0].lower() + key[1:], None) or default
        if not handler and not optional:
            raise Exception("Missing handler for " + key + " / " +  key[0].lower() + key[1:] + " on " + self.__class__)
        return handler(view, scene) if handler else view


class Layout(Filter):

    def filterView(self, view, scene):
        if hasattr(scene, 'layout'):
            return scene.layout(view)
        else:
            return self.keyedFilterView(view, scene)


class Localizer(Filter):

    def __init__(self):
        self.strings = {}
        self.localizableProperties = { 'text' : 'text', 'key' : 'text' }

    def addLocalizableProperty(self, sourceProp, targetProp = None):
        self.localizableProperties[sourceProp] = (targetProp or sourceProp)

    def addString(self, key, text):
        self.strings[key] = text

    def addStringDictionary(self, strings):
        self.strings.update(strings)

    def filterView(self, view, scene):
        for v in view.recursiveSubviews():
            for sourceKey, targetKey in self.localizableProperties.iteritems():
                key = v.properties.get(sourceKey)
                if key and key in self.strings and (targetKey not in v.properties or v.properties[targetKey] == key):
                    v.properties[targetKey] = self.strings[v.properties[sourceKey]]
        return view


class Consumer(object):

    def __init__(self):
        self.manager = None

    def consume(self, message):
        pass

    def sendMessage(self, message):
        self.manager.sendMessageFromConsumer(message)


class Manager(object):

    def __init__(self):
        self.producer = SceneProducer(self)
        self.filters = None
        self.consumer = None
        self.on_load = None
        self.scenes = []
        self._nextViewId = 1

    def nextViewId(self):
        viewId = self._nextViewId
        self._nextViewId += 1
        return viewId

    def addFilter(self, chainFilter):
        if not self.filters:
            self.filters = [ chainFilter ]
        else:
            self.filters.append(chainFilter)

    def addConsumer(self, consumer):
        if self.consumer:
            raise Exception("already has a consumer")
        consumer.manager = self
        self.consumer = consumer

    def start(self):
        self.producer.start()

    def sendMessageFromProducer(self, view, scene):
        for f in self.filters:
            f.filterView(view, scene)
        self.consumer.consume({ 'newView' : view.dictionary(), 'parent' : 0 })

    def sendMessageFromConsumer(self, message):
        self.producer.handleMessage(message)

    def sendViewMessage(self, viewId, message, params = None):
        m = { 'message' : message, 'view' : viewId }
        if params:
            m['params'] = params
        self.consumer.consume(m)

    def addScene(self, scene):
        self.scenes.append(scene)
        self.producer.sendScene(scene)

    def removeScene(self, scene):
        # direct message to consumer
        self.consumer.consume({ 'removeView' : scene.container.viewId })
        self.scenes.remove(scene)

    def sendScenes(self):
        if not self.scenes and self.on_load:
            self.on_load()
            self.on_load = None
        for scene in self.scenes:
            self.producer.sendScene(scene)

    def handleViewMessage(self, message):
        #print("Got view message: " + str(message))
        if "viewId" not in message:
            return
        viewId = message["viewId"]
        scene = None
        obj = None
        view = None
        for s in self.scenes:
            if viewId == s.container.viewId:
                scene = s
                break
            elif s.hasViewId(viewId):
                scene = s
                view = scene.viewMap[viewId]
                obj = scene.objectForView(view)
                break

        if view and view.target:
            view.target(message)
        else:
            handler = (scene.handlerForObject(obj) if scene and obj else None) or \
                      getattr(obj, "handleViewMessage", None) or \
                      getattr(scene, "handleViewMessage", None) or \
                      self.messageHandler
            handler(scene, obj, message)


class Scene(object):

    def __init__(self, manager, key):
        self.manager = manager
        self.objectToViewMap = {}
        self.viewMap = {}
        self.key = key
        self.buttonMap = {}
        self.container = View(self)
        self.container.viewId = manager.nextViewId()
        self.build()

    def build(self):
        pass

    def hasViewId(self, viewId):
        return (None != self.viewMap.get(viewId))

    def objectForViewId(self, viewId):
        return self.viewMap[viewId].obj

    def objectForView(self, view):
        return view.obj

    def hasObject(self, obj):
        return (None != self.objectToViewMap.get(id(obj)))

    def viewForObject(self, obj):
        return self.objectToViewMap[id(obj)]

    def addView(self, view):
        if view.viewId:
            return view
        view.viewId = self.manager.nextViewId()
        self.viewMap[view.viewId] = view
        if not view.parent:
            self.container.addSubview(view)
        if view.obj:
            oid = id(view.obj)
            self.objectToViewMap[oid] = view
        if isinstance(view, Button) and view.key:
            self.buttonMap[view.key] = view
        return view

    def sendViewMessage(self, view, message, params = None):
        self.manager.sendViewMessage(view.viewId, message, params)

    def handlerForObject(self, obj):
        if obj:
            for base in cjb.util.superclassNames(obj):
                handler = getattr(self, "handle" + base + "Message", None)
                if handler:
                    return handler
        return None

    # helpers
    def targetButton(self, target):
        self.addView(Button(target = target))

    def targetButtons(self, targets):
        for target in targets:
            self.targetButton(target)

    def buttonWithKey(self, key):
        return self.buttonMap.get(key)

    def parseModel(self, model):
        return cjb.uif.views.parseModel(self, model)



class NetConsumer(Consumer):

    def __init__(self, host = 'localhost', port = '5555'):
        cjb.uif.Consumer.__init__(self)
        self.clients = []
        self.stop_on_disconnect = False
        self.server = cjb.util.server.socketMessageServer(host, port)
        self.server.messageHandler = self.messageHandler
        self.server.clientHandler = self.clientHandler
        self.server.disconnectHandler = self.disconnectHandler
        self.server.start()

    def clientHandler(self, client):
        print("Client connected: " + str(client.client_address))
        self.clients.append(client)

    def disconnectHandler(self, client):
        print("Disconnected: " + str(client.client_address))
        self.clients.remove(client)
        if self.stop_on_disconnect:
            self.shutdown()

    def messageHandler(self, message, client):
        message = json.loads(message)
        if "ui" in message and message["ui"] == "quit":
            client.disconnect()
        else:
            self.sendMessage(message)

    def consume(self, payload):
        try:
            message = json.dumps(payload)
        except:
            print("JSON encoding error for payload: " + str(payload))
            raise
        for client in self.clients:
            try:
                client.sendMessage(message)
            except:
                print("Warning: client send failed -- " + str(client.address) + ":" + str(client.port))

    def waitFor(self):
        self.server.waitForCtrlC()
        print("\nServer stopped.")

    def shutdown(self):
        self.server.shutdown()


class UIServer(object):

    def __init__(self, host = 'localhost', port = 9991, portFile = '/tmp/uif.port', tryAlternates = True, layout = None):

        self.manager = Manager()
        self.manager.on_load = self.home
        self.manager.addFilter(layout or Layout())
        usePort = port
        serving = False
        while not serving:
            try:
                self.manager.addConsumer(NetConsumer(host, usePort))
                serving = True
            except:
                if usePort > port + 4 or not tryAlternates:
                    raise
                usePort += 1
        cjb.util.writeDataToFileAtPath(str(port), portFile)

        self.curScene = None

    @property
    def stop_on_disconnect(self):
        return self.manager.consumer.stop_on_disconnect

    @stop_on_disconnect.setter
    def stop_on_disconnect(self, val):
        self.manager.consumer.stop_on_disconnect = val

    def addFilter(self, f):
        self.manager.addFilter(f)

    def start(self):
        self.manager.start()

    def waitFor(self):
        self.manager.consumer.waitFor()

    def shutdown(self):
        self.manager.consumer.shutdown()

    def home(self):
        pass

    def setScene(self, scene):
        self.manager.addScene(scene)
        if self.curScene:
            self.manager.removeScene(self.curScene)
        self.curScene = scene

    def pushScene(self, scene):
        self.manager.addScene(scene)
        self.curScene = scene

    def popScene(self):
        if self.curScene:
            self.manager.removeScene(self.curScene)
        self.curScene = self.manager.scenes[-1] if len(self.manager.scenes) > 0 else None
        return self.curScene

    def popToTop(self):
        while len(self.manager.scenes) > 1:
            self.manager.removeScene(self.manager.scenes[-1])
        self.curScene = self.manager.scenes[0] if len(self.manager.scenes) > 1 else None
        return self.curScene
