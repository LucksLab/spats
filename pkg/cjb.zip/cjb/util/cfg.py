
import ConfigParser
import os

def parse(configFile):
    if not os.path.exists(configFile):
        raise Exception("File not found: " + configFile)
    parser = ConfigParser.SafeConfigParser()
    #parser.optionxform = self.optionxform
    parser.read(configFile)
    config = {}
    for section in parser.sections():
        if section not in config:
            config[section] = {}
        for name, value in parser.items(section):
            config[section][name] = value
    return config

example = '''
[tree]
foo = value
bar = value
baz = %(foo)s and bar

[abc]
greek = bloody hell

[def]
greek = bloody hells
'''
