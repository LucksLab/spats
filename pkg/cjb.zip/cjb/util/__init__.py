
import datetime
import inspect
import json
import pytz

def flatten(listOfLists):
    return [item for sublist in listOfLists for item in sublist]

def stamp(dayOnly = True):
    return datetime.datetime.now().strftime('%Y%m%d' if dayOnly else '%Y%m%d_%H%M')

def dataWithFileAtPath(path):
    return open(path, 'rb').read()

def writeDataToFileAtPath(data, path):
    open(path, 'wb').write(data)

def jsonAtPath(path):
    return json.loads(dataWithFileAtPath(path))

def writeJsonToPath(dictionary, path, pretty = False):
    return writeDataToFileAtPath(json.dumps(dictionary, sort_keys = pretty, indent = 4 if pretty else None, separators = (',', ': ') if pretty else None), path)

def dispatchToHandler(handler, possibleArgs, classMethod = True):
    numArgs = len(inspect.getargspec(handler)[0])
    numArgs = (numArgs - 1) if classMethod else numArgs
    if 3 == numArgs:
        handler(possibleArgs[0], possibleArgs[1], possibleArgs[2])
    elif 2 == numArgs:
        handler(possibleArgs[0], possibleArgs[1])
    elif 1 == numArgs:
        handler(possibleArgs[0])
    else:
        handler()

def classname(obj):
    return obj.__class__.__name__

def superclasses(obj):
    return inspect.getmro(obj.__class__)

def superclassNames(obj):
    return [ base.__name__ for base in superclasses(obj) ]
