
import copy
import psutil
import socket
import threading
import time


# returns pid, name
def processWithOpenDocument(pathToDocument):
    for proc in psutil.process_iter():
        try:
            pinfo = proc.as_dict(attrs=['pid', 'name', 'exe', 'open_files'])
        except psutil.NoSuchProcess:
            pass
        else:
            files = pinfo.get('open_files') or []
            for f in files:
                # b/c sometimes docs (e.g. numbers) are folders
                if f.path.startswith(pathToDocument):
                    return pinfo['pid'], pinfo['name']
    return None, None


class Monitor(object):

    def __init__(self, newCallback = None, deadCallback = None, pollInterval = 1.0):
        self.newCallback = newCallback or (lambda x, y : None)
        self.deadCallback = deadCallback or (lambda x, y : None)
        self.monitoring = False
        self.thread = None
        self.pollInterval = pollInterval
        self.lastValues = {}

    def start(self):
        if self.monitoring or self.thread:
            return
        self.monitoring = True
        self.thread = threading.Thread(target = self._run)
        self.thread.start()

    def stop(self):
        self.monitoring = False
        if self.thread:
            self.thread.join()
        self.thread = None

    def _run(self):
        while self.monitoring:
            self.iterate()
            time.sleep(self.pollInterval)

    def changes(self, prevDict, curDict):
        newBits = []
        goneBits = []
        if 0 < len(prevDict):
            for cur in curDict.keys():
                if cur in prevDict:
                    del(prevDict[cur])
                else:
                    newBits.append((cur, curDict[cur]))
            for prev in prevDict.keys():
                goneBits.append((prev, prevDict[prev]))
        return newBits, goneBits

    def iterate(self):
        curDict = self._currentStatus()
        newVals, deadVals = self.changes(self.lastValues, curDict)
        for cb, vals in [ (self.newCallback, newVals), (self.deadCallback, deadVals) ]:
            for key, val in vals:
                cb(key, val)
        self.lastValues = curDict

    def _currentStatus(self):
        raise Exception("for subclasses")


class ProcessMonitor(Monitor):

    def _currentStatus(self):
        curProcs = {}
        for proc in psutil.process_iter():
            try:
                pinfo = proc.as_dict(attrs=['pid', 'name', 'exe'])
                curProcs[pinfo['pid']] = (pinfo['name'], pinfo['exe'])
            except psutil.NoSuchProcess:
                pass
        return curProcs

class NetMonitor(Monitor):

    def _currentStatus(self):
        curConns = {}
        for conn in psutil.net_connections('inet'):
            if 0 < len(conn[4]):
                key = "{}_{}_{}_{}".format(conn[6], conn[0], conn[4][0], conn[4][1])
                curConns[key] = conn
        return curConns

class FileMonitor(Monitor):

    def _currentStatus(self):
        cur = {}
        for proc in psutil.process_iter():
            try:
                pinfo = proc.as_dict(attrs=['pid', 'name', 'exe', 'open_files'])
            except psutil.NoSuchProcess:
                pass
            else:
                files = pinfo.get('open_files') or []
                for f in files:
                    key = "{}_{}".format(pinfo['pid'], f.fd)
                    cur[key] = { "f" : f, "pid" : pinfo['pid'] }
        return cur

def processWithOpenDocument(pathToDocument):
    for proc in psutil.process_iter():
        try:
            pinfo = proc.as_dict(attrs=['pid', 'name', 'exe', 'open_files'])
        except psutil.NoSuchProcess:
            pass
        else:
            files = pinfo.get('open_files') or []
            for f in files:
                # b/c sometimes docs (e.g. numbers) are folders
                if f.path.startswith(pathToDocument):
                    return pinfo['pid'], pinfo['name']
    return None, None


def dump(pid, vals, label):
    print "{}: {} ({}, {})".format(label, vals[0], pid, vals[1])

def monitor(mon):
    mon.start()
    print "Monitoring..."
    try:
        while True:
            time.sleep(10)
    except:
        print "...interrupted"
        mon.stop()

def procmonitor():
    monitor(ProcessMonitor(lambda pid, vals: dump(pid, vals, "-> NEW"),
                           lambda pid, vals: dump(pid, vals, " <DEAD")))

def dumpconn(key, conn, label):
    raddr = conn[4]
    try:
        hostname = socket.gethostbyaddr(raddr[0])[0]
    except:
        hostname = "<?>"
    print "{}: {} ({}, {})".format(label, raddr[0], conn[6], hostname)

def netmonitor():
    monitor(NetMonitor(lambda key, conn: dumpconn(key, conn, "-> NEW"),
                       lambda key, conn: dumpconn(key, conn, " <DEAD"),
                       pollInterval = 0.1))

def dumpfile(key, f, label):
    print "{}: {}-{} ({})".format(label, f["pid"], f["f"].fd, f["f"].path)

def filemonitor():
    monitor(FileMonitor(lambda key, f: dumpfile(key, f, "-> NEW"),
                        lambda key, f: dumpfile(key, f, " <DEAD")))
