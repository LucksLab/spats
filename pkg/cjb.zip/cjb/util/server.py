
import socket
import SocketServer
import threading
import time
import traceback


def socketMessageServer(host = "localhost", port = 9999):
    return SocketMessageServer(host, port)


class SocketMessageServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):

    def __init__(self, host, port):
        SocketServer.TCPServer.__init__(self, (host, port), ThreadedTCPRequestHandler)
        self.ip, self.port = self.server_address
        self.clients = []
        self.clientHandler = lambda client : None
        self.disconnectHandler = lambda client : None
        self.messageHandler = lambda message, client : None
        self.messageWillSend = lambda message, client : None

    def start(self):
        self.thread = threading.Thread(target = self.serve_forever)
        self.thread.daemon = True
        self.thread.start()

    def clientConnected(self, client):
        self.clients.append(client)
        self.clientHandler(client)

    def clientDisconnected(self, client):
        if client in self.clients:
            self.clients.remove(client)
        self.disconnectHandler(client)

    def waitForCtrlC(self, shutdownAfter = True):
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        if shutdownAfter:
            self.shutdown()

    def shutdown(self):
        while len(self.clients) > 0:
            client = self.clients[0]
            client.disconnect()
            time.sleep(0.01)
            if client in self.clients:
                self.clients.remove(client)
        SocketServer.TCPServer.shutdown(self)


class ThreadedTCPRequestHandler(SocketServer.BaseRequestHandler):

    def sendMsg(self, message):
        self.request.sendall(message + "\n")

    def setup(self):
        self.address, self.port = self.client_address
        self.sendQueue = []
        self.sendQueueLock = threading.Lock()
        self._disconnect = False

    def handle(self):
        self.setup()
        self.server.clientConnected(self)
        self.request.setblocking(0)
        self.request.settimeout(5.0)
        try:
            while not self._disconnect:
                self._sendQueuedMessages()
                data = None
                try:
                    data = self.request.recv(4096)
                    if not data:
                        self._disconnect = True
                except socket.timeout:
                    pass
                if data:
                    for msg in data.split('\n'):
                        stripped = msg.strip()
                        if len(stripped) > 0:
                            try:
                                self.server.messageHandler(stripped, self)
                            except:
                                print "Unhandled exception in message handler"
                                print "Message: " + str(stripped)
                                print "Exception:\n" + traceback.format_exc()
        except:
            print "Socket failure:\n"
            print traceback.format_exc()
        self.server.clientDisconnected(self)
        self.request.close()

    def _sendQueuedMessages(self):
        try:
            self.sendQueueLock.acquire()
            for message in self.sendQueue:
                self.server.messageWillSend(message, self)
                if len(message) > 65536:
                    print " LONG SEND: {}k".format(len(message) >> 10)
                self.request.sendall(message + "\n")
            self.sendQueue = []
        finally:
            self.sendQueueLock.release()

    def sendMessage(self, message):
        try:
            self.sendQueueLock.acquire()
            self.sendQueue.append(message)
        finally:
            self.sendQueueLock.release()

    def disconnect(self):
        self._disconnect = True
