
import subprocess

def osaExecute(osa):
    return subprocess.check_output([ "osascript", "-e", osa ])

getWindowUrlsScript = '''
set text item delimiters to linefeed
tell application "{app}" to URL of tabs of window 0 as text
'''

def getWindowUrls(app):
    resp = osaExecute(getWindowUrlsScript.format(app = app))
    return [ url.strip() for url in resp.strip('"').split('\n') if len(url.strip()) > 0 ]

def openUrlsInNewWindow(app, urls):
    if 0 == len(urls):
        return
    script = 'tell application "{app}"\n'.format(app = app)
    if app == 'Safari':
        script += '	make new document with properties {{URL:"{url}"}}\n'.format(url = urls[0])
    else:
        script += '	set URL of active tab of window 0 to "{url}"\n'.format(url = urls[0])
    for url in urls[1:]:
        script += '	make new tab in window 0 with properties {{URL:"{url}"}}\n'.format(url = url)
    script += 'end tell\n'
    try:
        osaExecute(script)
    except:
        # maybe browser was already launched but didn't have a window open.
        osaExecute('tell application "{app}" to make new window'.format(app = app))
        osaExecute(script)

def launchApp(app):
    osaExecute('launch application "{app}"'.format(app = app))

def bringToFront(app):
    osaExecute('tell application "{app}" to activate'.format(app = app))

def closeWindows(app):
    osaExecute('tell application "{app}" to close windows'.format(app = app))

def quitApp(app):
    osaExecute('tell application "{app}" to quit'.format(app = app))
