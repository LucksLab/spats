
def debug(str):
    pass #print str

def hierarchyParse(str):
    item, lines = hierarchyParseNode(str.split('\n'))
    return item

def hierarchyParseNode(lines, parent = None, parentPrefix = -1):
    if not lines:
        return None, None
    line = lines[0]
    rest = lines[1:]
    if 0 == len(line.strip()):
        return hierarchyParseNode(rest, parent, parentPrefix)

    debug("line" + str(parentPrefix) + ">" + line)
    if parent:
        debug(" p=" + parent.get("name", "(anon)"))
    prefix = len(line) - len(line.lstrip())
    if prefix <= parentPrefix:
        return None, lines

    lineItems = line[prefix:].split(' ', 1)
    if lineItems[0].startswith('@'):
        key = lineItems[0][1:]
        parent[key] = lineItems[1] if 2 == len(lineItems) else ''
        return hierarchyParseNode(rest, parent, parentPrefix)

    item = { "type" : lineItems[0], "children" : [] }
    if len(lineItems) > 1:
        item["name"] = lineItems[1]

    while True:
        child, rest = hierarchyParseNode(rest, item, prefix)
        if child:
            item["children"].append(child)
        else:
            break

    return item, rest
