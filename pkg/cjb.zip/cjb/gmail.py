
import httplib2
import os

from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage


class Gmail():

    def __init__(self, client_key, credentials):
        self.client_key = client_key
        self.credentials = credentials
        self.scopes = 'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send'
        self.authenticated = False
        self.service = None

    def authenticate(self):
        if self.authenticated:
            return
        store = Storage(self.credentials)
        credentials = store.get()
        if not credentials or credentials.invalid:
            flow = client.flow_from_clientsecrets(self.client_key, self.scopes)
            flow.user_agent = 'mos'
            credentials = tools.run_flow(flow, store)
        self.credentials = credentials
        self.authenticated = True

    def connect(self):
        if self.service:
            return
        self.authenticate()
        http = self.credentials.authorize(httplib2.Http())
        self.service = discovery.build('gmail', 'v1', http=http)

    def labels(self):
        self.connect()
        results = self.service.users().labels().list(userId='me').execute()
        return [ label['name'] for label in results.get('labels', []) ]

    def unreadMessages(self):
        self.connect()
        result = self.service.users().messages().list(userId='me', q='label:inbox label:unread').execute()
        messages = []
        for msg in result["messages"]:
            msgId = msg["id"]
            msgInfo = { "id" : msgId }
            msgResult = self.service.users().messages().get(userId='me', id=msgId, format='metadata', metadataHeaders=['From','Subject']).execute()
            msgInfo["preview"] = msgResult["snippet"]
            msgInfo["stamp"] = msgResult["internalDate"]
            for hdr in msgResult["payload"]["headers"]:
                if hdr["name"].lower() == "from":
                    msgInfo["from"] = hdr["value"]
                if hdr["name"].lower() == "subject":
                    msgInfo["subject"] = hdr["value"]
            messages.append(msgInfo)
        return messages

def test(client_key, credentials):
    results = Gmail(client_key, credentials).unreadMessages()
    for item in results:
        print u'{f}   {sub}  --  {text}'.format(f = item["from"], sub = item["subject"], text = item["preview"])

