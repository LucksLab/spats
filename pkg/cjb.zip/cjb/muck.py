


class Muck():

    def __init__(self, otherCrap = None):
        self.objects = {}

    def __setitem__(self, name, value):
        self.objects[name] = value

    def __getitem__(self, name):
        return self.objects.get(name)

    def dump(self):
        import json
        return json.dumps(self.objects, sort_keys=True, indent=2)

class MuckPersistor():

    def __init(self):
        self.objects = {}



class MuckObject():

    def __init__(self, identifier = 0):
        self.identifier = identifier

    def load(self, persistor):
        pass

    def persist(self, persistor):
        pass
