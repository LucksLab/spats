
import os
import random
import shutil

import cjb.mos.task
import cjb.mos.taskdef
import cjb.muck
import cjb.util.cfg


g_uid_range = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
def generateId(len=6):
    return ''.join(random.choice(g_uid_range) for i in range(len))


class Mos():

    def __init__(self):
        self.muck = cjb.muck.Muck()
        self.setup()

    def setup(self):
        self.configDir = os.path.expanduser("~/mos/etc")
        self.config = cjb.util.cfg.parse(os.path.join(self.configDir, 'mos.cfg'))
        self.loadTaskDefs()
        self.baseDir = self.config["mos"]["basedir"]
        self.taskDir = self.config["mos"]["taskdir"]
        self.deletedTaskDir = os.path.join(os.path.dirname(self.taskDir), "deleted_tasks")
        self.loadTasks()

    def workDir(self):
        workDir = os.path.join(self.baseDir, "work")
        if not os.path.exists(workDir):
            os.mkdir(workDir)
        return workDir

    def configFile(self, filename):
        return os.path.join(self.configDir, filename)

    def mailAccounts(self):
        accountId = 0
        accounts = []
        while True:
            account = self.config.get('mail_{}'.format(accountId))
            if not account:
                return accounts
            accounts.append(account)
            accountId += 1

    def loadTasks(self):
        import cjb.mos.widget # TODO..
        self.tasks = []
        self.tasksByIdentifier = {}
        for taskId in os.listdir(self.taskDir):
            if taskId.startswith('.'):
                continue
            task = cjb.mos.widget.Task(self)
            task.load(taskId)
            self._addTask(task)

    def _addTask(self, task):
        self.tasks.append(task)
        self.tasksByIdentifier[task.identifier] = task

    def deleteTask(self, task):
        taskId = task.identifier
        del(self.tasksByIdentifier[taskId])
        self.tasks.remove(task)
        if not os.path.exists(self.deletedTaskDir):
            os.mkdir(self.deletedTaskDir)
        shutil.move(os.path.join(self.taskDir, taskId), os.path.join(self.deletedTaskDir, taskId))

    def taskWithIdentifier(self, taskId):
        return self.tasksByIdentifier[taskId]

    def loadTaskDefs(self):
        self.taskdefs = cjb.mos.taskdef.taskdefs()
        self.taskdefsByName = { taskdef.name : taskdef for taskdef in self.taskdefs }

    def taskdefWithName(self, name):
        return self.taskdefsByName[name]

    def createTaskOfType(self, taskdef):
        import cjb.mos.widget # TODO..
        task = cjb.mos.widget.Task(self)
        task.create(generateId(), taskdef)
        self._addTask(task)
        return task


def run():
    from cjb.mos.launcher import Launcher
    Launcher().run()
