
import copy

from cjb.uif.layout import Size, layoutInScroller
from cjb.uif.views import Button, Scroller


buttonSize = Size(120, 40)
itemSize = Size(200, 60)
methodSize = Size(180, 30)


def basic(view, scene, size = itemSize):
    cur = view.frame.centeredSubrect(w = size.w, h = view.frame.size.h)
    layoutInScroller([v for v in view.subviews if v.obj], cur, size, 20)
    return view
