
from cjb.uif.layout import Size, layoutInScroller
from cjb.uif.views import Label, TextField, Scroller
from cjb.mos.scenes.base import BaseScene
import cjb.mos.layout
import cjb.mos.task
import cjb.mos.widget


class Task(BaseScene):

    def __init__(self, ui, task):
        self.task = task
        self.widgetActions = {}
        BaseScene.__init__(self, ui)
        self.openContext = None

    def build(self):
        self.addModelView(self.task, viewClass = Label)
        self.actions = self.addModelViews(self.task.actions(), selectable = True)
        self.widgets = self.addModelViews(self.task.widgets)
        for wv in self.widgets:
            self.addSelectableView(wv)
            self.widgetActions[wv.viewId] = self.addModelViews(wv.obj.actions(), selectable = True)
        self.widgetdefs = self.addModelViews(self.task.widgetDefs())
        self.renameField = TextField(target = self.renameFieldHandler)
        self.renameField.hidden = True

    def layout(self, view):
        BaseScene.layout(self, view)

        actions = view.frame.leftSubrect(0.33 * view.frame.size.width)
        widgets = view.frame.leftover

        actions = actions.layout(self.viewForObject(self.task), 'topCentered', 'leftover', w = 0.8 * actions.size.width, h = 60, margin = 20)
        layoutInScroller(self.actions, actions, Size(200, 60), 20)

        self.widgetScroller = Scroller()
        self.widgetScroller.frame = widgets
        self.addView(self.widgetScroller)
        cur = widgets.bounds()
        for wv in self.widgets:
            wv.frame = cur.topCenteredSubrect(300, 40, margin = 40)
            self.widgetScroller.addSubview(wv)
            cur = cur.leftover
            for wav in self.widgetActions[wv.viewId]:
                wav.frame = cur.topCenteredSubrect(200, 24, margin = 1)
                self.widgetScroller.addSubview(wav)
                cur = cur.leftover

        self.defScroller = layoutInScroller(self.widgetdefs, widgets, Size(300, 60), 40)
        self.addView(self.defScroller)
        self.defScroller.hidden = True

        self.addView(self.renameField)

        return view

    def handleTaskActionMessage(self, scene, obj, message):
        self.executeAction(obj)

    def handleWidgetActionMessage(self, scene, obj, message):
        self.executeAction(obj)

    def handleWidgetDefMessage(self, scene, obj, message):
        self.newWidgetWithDef(obj)

    def handleWidgetMessage(self, scene, obj, message):
        self.handleWidget(obj)

    def handleViewMessage(self, scene, obj, message):
        if message.get("event") == "openFile":
            self.handleOpenFile(message)
        else:
            BaseScene.handleViewMessage(self, scene, obj, message)

    def executeAction(self, action):
        actionId = action.identifier
        customHandler = getattr(self, actionId, None)
        if customHandler:
            customHandler(action)
        else:
            if isinstance(action, cjb.mos.widget.WidgetAction):
                action.widget.executeAction(action)
            else:
                self.task.executeAction(actionId)
        if not self.task.running:
            self.ui.taskFinished()

    def refresh(self):
        self.ui.setScene(Task(self.ui, self.task))

    def rename(self, action):
        self.renameAction = action
        view = self.viewForObject(action)
        frame = view.frame.add(point = view.parent.frame.origin)
        self.sendViewMessage(self.renameField, "moveTo", frame.array())
        self.sendViewMessage(self.renameField, "setText", action.widget.name if isinstance(action, cjb.mos.widget.WidgetAction) else self.task.name)
        self.sendViewMessage(self.renameField, "show")
        self.sendViewMessage(self.renameField, "focus")

    def remove(self, action):
        action.widget.executeAction(action)
        self.refresh()

    def renameFieldHandler(self, message):
        value = message["arg"]
        if isinstance(self.renameAction, cjb.mos.widget.WidgetAction):
            widget = self.renameAction.widget
            widget.rename(widget, value)
            self.sendViewMessage(self.viewForObject(widget), "setText", widget.name)
        else:
            self.task.rename(self.task, value)
            self.sendViewMessage(self.viewForObject(self.task), "setText", self.task.name)
        self.sendViewMessage(self.renameField, "hide")

    def newWidget(self, action):
        self.sendViewMessage(self.defScroller, "show")
        if self.widgetScroller:
            self.sendViewMessage(self.widgetScroller, "hide")

    def newWidgetWithDef(self, widgetdef):
        if widgetdef.identifier in [ 'doc','app' ]:
            self.openContext = widgetdef
            self.sendViewMessage(self.container, "openFile", { "multiple" : 0 , "folder" : 0 })
        else:
            self.task.newWidget(widgetdef)
            self.refresh()

    def handleOpenFile(self, message):
        obj = self.openContext
        self.openContext = None
        if isinstance(obj, cjb.mos.widget.WidgetAction):
            obj.widget.executeAction(obj, message['paths'])
        else:
            widget = self.task.newWidget(obj)
            obj.setPath(widget, message['paths'][0])
            self.refresh()

    def handleWidget(self, widget):
        pass # NOP for now

    def addDocs(self, action):
        self.openContext = action
        self.sendViewMessage(self.container, "openFile", { "multiple" : 1 , "folder" : 0 })

