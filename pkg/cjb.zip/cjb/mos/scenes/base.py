
import cjb.mos.layout
import cjb.uif
from cjb.uif.layout import Rect, multiplyWithSpacing
import cjb.uif.views


class BaseScene(cjb.uif.Scene):

    def __init__(self, ui, key = None):
        self.ui = ui
        self.selectableViews = []
        self.selectedView = None
        self.previousBgColors = {}
        cjb.uif.Scene.__init__(self, ui.manager, key or self.__class__.__name__)
        self.container.properties['sendKeys'] = 1

    @property
    def mos(self):
        return self.ui.mos

    def build(self):
        # common UI
        if self.key != 'Home':
            self.targetButton(self.ui.home)

    def layout(self, view):
        # common layout
        home = self.buttonWithKey('home')
        if home:
            home.frame = view.frame.bottomRightSubrect(size = cjb.mos.layout.buttonSize, margin = 20)
        return view

    def addModelView(self, obj, selectable = False, viewClass = cjb.uif.views.Button):
        view = viewClass(obj = obj)
        self.addView(view)
        return view

    def addModelViews(self, objs, selectable = False):
        ret = map(self.addModelView, objs)
        if selectable:
            map(self.addSelectableView, ret)
        return ret

    def addSelectableView(self, view):
        self.selectableViews.append(view)

    def addSelectableViews(self, views):
        map(self.addSelectableView, views)

    def handleViewMessage(self, scene, obj, message):
        if obj:
            print "App got message to " + str(obj) + ": " + str(message)
        elif message.get('event') == 'key':
            self.handleKeyEvent(message["arg"])
        else:
            print "App got general message: " + str(message)

    def handleKeyEvent(self, keyInfo):
        if keyInfo.get("t") == "h" and 1 == keyInfo.get("ctrl"):
            self.ui.home()
        elif len(self.selectableViews) > 0:
            if keyInfo.get("s"):
                if keyInfo["s"] == "RET":
                    self.activateSelectedView()
                else:
                    index = self.selectableViews.index(self.selectedView) if self.selectedView else 0
                    numViews = len(self.selectableViews)
                    if keyInfo["s"] == "RIGHT" or keyInfo["s"] == "DOWN":
                        index = index + 1 if self.selectedView else index
                    elif keyInfo["s"] == "LEFT" or keyInfo["s"] == "UP":
                        index = index + numViews - 1 if self.selectedView else numViews - 1
                    else:
                        print "Unhandled key: " + str(keyInfo)
                        return
                    self.selectView(self.selectableViews[index % numViews])
            elif keyInfo.get("t"):
                self.trySelectingByName(keyInfo)
            else:
                print "Unhandled key: " + str(keyInfo)
        else:
            print "Unhandled key: " + str(keyInfo)

    def selectView(self, view):
        oldView = self.selectedView
        self.selectedView = view
        self.didSelectView(self.selectedView, oldView)

    def trySelectingByName(self, keyInfo):
        keyChar = keyInfo["t"]
        numViews = len(self.selectableViews)
        index = 1 + self.selectableViews.index(self.selectedView) if self.selectedView else 0
        for delta in range(numViews):
            v = self.selectableViews[(index + delta) % numViews]
            if v.obj and hasattr(v.obj, "displayName") and v.obj.displayName.lower().startswith(keyChar):
                self.selectView(v)
                return
        print "Unhandled key: " + str(keyInfo)

    def activateSelectedView(self):
        if not self.selectedView:
            print "No view selected, cannot activate"
            return
        handler = self.handlerForObject(self.selectedView.obj)
        if handler:
            handler(self, self.selectedView.obj, None)
        else:
            print "Selected view activation unhandled"

    def didSelectView(self, newView, oldView):
        if oldView:
            self.sendViewMessage(oldView, "setBg", self.previousBgColors[oldView.viewId])
        self.previousBgColors[newView.viewId] = newView.bg
        self.sendViewMessage(newView, "setBg", [ 0.7, 0.8, 1.0 ])
        self.sendViewMessage(newView, "scrollToVisible")

    def startTask(self, task):
        self.ui.startTask(task)
