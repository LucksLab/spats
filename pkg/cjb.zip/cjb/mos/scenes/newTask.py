
from cjb.mos.scenes.base import BaseScene
import cjb.mos.layout
import cjb.mos.taskdef


class NewTask(BaseScene):

    def build(self):
        BaseScene.build(self)
        self.addModelViews(self.mos.taskdefs, selectable = True)

    def layout(self, view):
        BaseScene.layout(self, view)
        return cjb.mos.layout.basic(view, self)

    def handleTaskDefMessage(self, scene, obj, message):
        self.startTask(self.mos.createTaskOfType(obj))
