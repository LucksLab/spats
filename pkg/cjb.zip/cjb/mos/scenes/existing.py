
from cjb.mos.scenes.base import BaseScene
import cjb.mos.layout
import cjb.mos.task


class ExistingTask(BaseScene):

    def build(self):
        BaseScene.build(self)
        self.addModelViews(sorted(self.mos.tasks, key = lambda t: t.displayName.lower()), selectable = True)

    def layout(self, view):
        BaseScene.layout(self, view)
        return cjb.mos.layout.basic(view, self)

    def handleTaskMessage(self, scene, obj, message):
        self.startTask(obj)
