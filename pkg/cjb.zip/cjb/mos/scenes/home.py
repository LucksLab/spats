
from cjb.uif.layout import Size, Grid
import cjb.mos.scenes
from cjb.mos.scenes import BaseScene


class Home(BaseScene):

    def build(self):
        BaseScene.build(self)
        self.targetButtons([self.existingTask, self.newTask])

    def handleKeyEvent(self, keyInfo):
        handler = { "e" : self.existingTask,
                    "n" : self.newTask }.get(keyInfo.get("t", ''))
        if handler:
            handler()
        else:
            BaseScene.handleKeyEvent(self, keyInfo)

    def layout(self, view):
        grid = Grid(frame = view.frame, itemSize = Size(500, 100), columns = 1, rows = 2, spacing = Size(100, 200))
        grid.applyToViews([ v for v in view.subviews if getattr(v, "key", None) != 'home' ])
        return view

    def newTask(self, message = None):
        self.ui.setScene(cjb.mos.scenes.NewTask(self.ui))

    def existingTask(self, message = None):
        self.ui.setScene(cjb.mos.scenes.ExistingTask(self.ui))
