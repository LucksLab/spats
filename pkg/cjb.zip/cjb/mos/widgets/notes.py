
import os
import cjb.mos.app
import cjb.mos.widget


class NotesWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "notes"
        self.name = "Notes"
        self.description = "Task notes."

    def isVisible(self, widget):
        return self.app(widget) and self.app(widget).isRunning()

    def app(self, widget):
        return widget.state.get("app")

    def path(self, widget):
        return os.path.join(widget.task.workspacePath, 'NOTES_' + widget.task.name)

    def show(self, widget):
        if self.isVisible(widget):
            return
        app = cjb.mos.app.emacs(initFile = widget.task.mos.configFile('mos.emacs'))
        widget.state["app"] = app
        app.fileToEdit = self.path(widget)
        app.launch(widget.task)

    def hide(self, widget):
        if not self.isVisible(widget):
            return
        self.app(widget).terminate(widget.task)

    def stop(self, widget):
        if self.isVisible(widget):
            self.hide(widget)

    def remove(self, widget):
        # NOP: keep notes around, just in case
        pass

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "show", "Show notes") ]

widget = NotesWidget()
