
import datetime
import os
import shutil
import cjb.mos.app
import cjb.mos.widget
import cjb.util


class DraftWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "draft"
        self.name = "Draft Mail"
        self.description = "Draft an email."

    def isDraftVisible(self, widget):
        return self.drafter(widget) and self.drafter(widget).isRunning()

    def isComposerVisible(self, widget):
        return self.composer(widget) is not None

    def drafter(self, widget):
        return widget.state.get("drafter")

    def composer(self, widget):
        return widget.state.get("composer")

    def path(self, widget):
        return os.path.join(widget.task.workspacePath, 'DRAFT_{}_{}'.format(widget.identifier, widget.task.name))

    def show(self, widget):
        if self.isDraftVisible(widget):
            return
        app = cjb.mos.app.emacs(initFile = widget.task.mos.configFile('mos.emacs'))
        widget.state["drafter"] = app
        app.fileToEdit = self.path(widget)
        app.launch(widget.task)

    def hide(self, widget):
        if self.isDraftVisible(widget):
            self.drafter(widget).terminate(widget.task)
            widget.state["drafter"] = None
        if self.isComposerVisible(widget):
            self.composer(widget).terminate(widget.task)
            widget.state["composer"] = None

    def stop(self, widget):
        self.hide(widget)

    def remove(self, widget):
        # NOP: we keep drafts around, just in case
        pass

    def resetBody(self, widget):
        stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M')
        path = self.path(widget)
        backup = path + "_" + stamp
        shutil.copyfile(path, backup)
        draft = DraftProcessor(cjb.util.dataWithFileAtPath(self.path(widget)))
        cjb.util.writeDataToFileAtPath(draft.headers, path)

    def showWithNewBody(self, widget):
        self.resetBody(widget)
        self.show(widget)

    def sendStripped(self, widget):
        self.send(widget)

    def sendUnchanged(self, widget):
        self.send(widget, stripped = False)

    def send(self, widget, stripped = True):
        if self.isDraftVisible(widget):
            self.hide(widget)

        mos = widget.task.mos
        draft = DraftProcessor(cjb.util.dataWithFileAtPath(self.path(widget)), mos.config["mail_aliases"], stripped)

        #print "parsed body:\n---------------------\n" + draft.body + "\n---------------------\n"

        accounts = mos.mailAccounts()
        account = None
        for acct in accounts:
            if acct['email'] == draft.fromEmail or not account:
                account = acct
        sessionId = account.get('sessionid', 0) if account else 0

        # TODO: can we use gmail api to set up a draft and then link to that?
        url = 'https://mail.google.com/mail/u/{}/?{}'.format(sessionId, draft.gmailComposeArgs())

        app = cjb.mos.app.chrome()
        widget.state["composer"] = app
        app.launch(widget.task)
        app.showUrls([url])
        app.bringToFront(widget.task)

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "show", "Show draft"),
                 cjb.mos.widget.WidgetAction(widget, "showWithNewBody", "Show draft and reset body"),
                 cjb.mos.widget.WidgetAction(widget, "sendStripped", "Send draft (fix newlines)"),
                 cjb.mos.widget.WidgetAction(widget, "sendUnchanged", "Send draft (exactly as-is)"), ]


class DraftProcessor(object):

    def __init__(self, draft, aliases = None, stripped = True):
        self.strip = stripped
        self.draft = draft
        self.aliases = aliases or {}
        self.toEmails = None
        self.fromEmail = None
        self.cc = None
        self.bcc = None
        self.subject = None
        self.headers = None
        self.body = None

        # aliases
        self.parse_s = self.parse_subject
        self.parse_re = self.parse_subject
        self.parse_sub = self.parse_subject
        self.parse_t = self.parse_to
        self.parse_f = self.parse_from

        self.parse()

    def parse_to(self, bits):
        rcpts = [ r.strip() for r in bits[1].split(',') ]
        self.toEmails = [ self.aliases.get(r, r) for r in rcpts ]

    def parse_cc(self, bits):
        rcpts = [ r.strip() for r in bits[1].split(',') ]
        self.cc = [ self.aliases.get(r, r) for r in rcpts ]

    def parse_bcc(self, bits):
        rcpts = [ r.strip() for r in bits[1].split(',') ]
        self.bcc = [ self.aliases.get(r, r) for r in rcpts ]

    def parse_from(self, bits):
        f = bits[1].strip()
        self.fromEmail = self.aliases.get(f, f)

    def parse_subject(self, bits):
        self.subject = bits[1].strip()

    def gmailComposeArgs(self):
        # TODO: urlencode? maybe not necessary, looks like chrome does it...
        args = 'view=cm&fs=1&tf=1'
        if self.toEmails:
            args += '&to={}'.format(','.join(self.toEmails))
        if self.cc:
            args += '&cc={}'.format(','.join(self.cc))
        if self.bcc:
            args += '&bcc={}'.format(','.join(self.bcc))
        if self.subject:
            args += '&su={}'.format(self.subject)
        args += '&body=' + self.body.replace('\n', '%0a')
        return args

    def parse(self):
        lines = self.draft.split('\n')
        self.headers = ""
        lastWrapped = False
        for line in lines:

            bits = line.split(":")
            if (not self.body)  and  (len(bits) >= 2):
                self.headers += line
                self.headers += '\n'
                handler = getattr(self, 'parse_' + bits[0].lower(), None)
                if handler:
                    try:
                        handler(bits)
                        continue
                    except:
                        print "exception handling mail line:  --  " + line
                        raise
                        if not self.body:
                            continue

            if not self.body:
                self.body = ""

            if not self.strip:
                self.body += line
                self.body += '\n'
                continue

            if 0 == len(line.strip()):
                if lastWrapped:
                    self.body += '\n'
                self.body += '\n'
                lastWrapped = False

            elif line.startswith(" ") and line.lstrip()[0] in [ "-", "+", "(", "[" ]:
                # looks like a bullet. copy it in straight
                self.body += line
                self.body += '\n'
                lastWrapped = False

            else:
                if not self.body.endswith(" "):
                    self.body += " "
                self.body += line.lstrip() # lstrip() because of possible indentation
                if len(line) > 40: # don't wrap short lines
                    lastWrapped = True
                else:
                    self.body += '\n'
                    lastWrapped = False

widget = DraftWidget()
