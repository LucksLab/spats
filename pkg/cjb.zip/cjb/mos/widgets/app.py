
import os
import shutil
import cjb.mos.widget
import cjb.util.osa


class AppWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "app"
        self.name = "Application"
        self.description = "Add an application."

    def appPath(self, widget):
        return widget.getConfig('appPath')

    def open(self, widget):
        cjb.mos.app.launchApp(widget.task, self.appPath(widget))

    def setPath(self, widget, path):
        widget.setConfig('appPath', path)

    def stop(self, widget):
        name, ext = os.path.splitext(os.path.basename(self.appPath(widget)))
        cjb.util.osa.quitApp(name)

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "open", "Open Application") ]

widget = AppWidget()
