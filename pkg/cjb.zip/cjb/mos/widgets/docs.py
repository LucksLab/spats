
import os
import shutil
import cjb.mos.widget
import cjb.util.osa


class DocsWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "docs"
        self.name = "Reference Documents"
        self.description = "Maintains a folder of reference documents."

    def path(self, widget):
        p = os.path.join(widget.task.workspacePath, 'docs')
        if not os.path.exists(p):
            os.mkdir(p)
        return p

    def show(self, widget):
        cjb.util.osa.closeWindows("Finder")
        cjb.mos.app.showDocument(widget.task, self.path(widget))

    def addDocs(self, widget, paths):
        for path in paths:
            target = os.path.join(self.path(widget), os.path.basename(path))
            if os.path.isdir(path):
                shutil.copytree(path, target)
            else:
                shutil.copyfile(path, target)

    def stop(self, widget):
        cjb.util.osa.closeWindows("Finder")

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "show", "Show Documents"),
                 cjb.mos.widget.WidgetAction(widget, "addDocs", "Add Documents") ]

widget = DocsWidget()
