
import os
import shutil
import cjb.mos.widget
import cjb.util.process


class DocWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "doc"
        self.name = "Document"
        self.description = "Add a document widget."

    def docPath(self, widget):
        return os.path.join(widget.task.workspacePath, widget.getConfig('docName'))

    def open(self, widget):
        cjb.mos.app.showDocument(widget.task, self.docPath(widget))

    def setPath(self, widget, path):
        name = os.path.basename(path)
        widget.setConfig('docName', name)
        if os.path.isdir(path):
            shutil.copytree(path, self.docPath(widget))
        else:
            shutil.copyfile(path, self.docPath(widget))

    def stop(self, widget):
        pid, name = cjb.util.process.processWithOpenDocument(self.docPath(widget))
        if name:
            cjb.util.osa.quitApp(name)
        else:
            print "Could not find process with open file: " + self.docPath(widget)

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "open", "Open Document") ]

widget = DocWidget()
