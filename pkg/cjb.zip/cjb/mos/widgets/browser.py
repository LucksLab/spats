
import cjb.mos.app
import cjb.mos.widget
import cjb.util.osa


class BrowserWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "browser"
        self.name = "Browser"
        self.description = "Open one or more URLs in a browser session."
        self.app = cjb.mos.app.chrome()

    def isVisible(self, widget):
        return widget.state.get("visible")

    def show(self, widget):
        if self.isVisible(widget):
            return
        self.app.launch(widget.task)
        self.app.showUrls(widget.getConfig("urls", [ "http://www.google.com" ]))
        self.app.bringToFront(widget.task)
        widget.state["visible"] = 1

    def hide(self, widget):
        if not self.isVisible(widget):
            return
        self.app.closeWindows()
        self.app.terminate(widget.task)
        widget.state["visible"] = 0

    def saveUrls(self, widget):
        if not self.isVisible(widget):
            return
        urls = cjb.util.osa.getWindowUrls(self.app.appName)
        print urls
        widget.setConfig("urls", urls)

    def stop(self, widget):
        if self.isVisible(widget):
            self.hide(widget)

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "show", "Show browser"),
                 cjb.mos.widget.WidgetAction(widget, "hide", "Hide browser"),
                 cjb.mos.widget.WidgetAction(widget, "saveUrls", "Save URL state") ]


widget = BrowserWidget()
