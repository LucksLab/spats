
import importlib
import pkgutil
import cjb.mos.widgets

WIDGETDEFS = []

def widgets():
    if 0 == len(WIDGETDEFS):
        for loader, name, ispkg in pkgutil.walk_packages(cjb.mos.widgets.__path__):
            WIDGETDEFS.append(importlib.import_module('cjb.mos.widgets.' + name).widget)
    return WIDGETDEFS
