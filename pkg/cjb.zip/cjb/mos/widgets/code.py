
import os
import cjb.mos.app
import cjb.mos.widget


class CodeWidget(cjb.mos.widget.WidgetDef):

    def __init__(self):
        self.identifier = "code"
        self.name = "Code"
        self.description = "Emacs session for coding."

    def isEditorVisible(self, widget):
        return self.editor(widget) and self.editor(widget).isRunning()

    def editor(self, widget):
        return widget.state.get("editor")

    def open(self, widget):
        if self.isEditorVisible(widget):
            return
        editor = cjb.mos.app.emacs(initFile = widget.task.mos.configFile('code.emacs'))
        editor.desktopFile = os.path.join(widget.task.workspacePath, 'emacs.desktop')
        widget.state["editor"] = editor
        editor.launch(widget.task)

    def isTerminalVisible(self, widget):
        return self.term(widget) and self.term(widget).isRunning()

    def term(self, widget):
        return widget.state.get("terminal")

    def terminal(self, widget):
        if self.isTerminalVisible(widget):
            return
        term = cjb.mos.app.terminal()
        widget.state["terminal"] = term
        term.launch(widget.task)

    def hide(self, widget):
        if self.isEditorVisible(widget):
            self.editor(widget).terminate(widget.task)
        if self.isTerminalVisible(widget):
            self.term(widget).terminate(widget.task)

    def stop(self, widget):
        self.hide(widget)

    def actions(self, widget):
        return [ cjb.mos.widget.WidgetAction(widget, "open", "Open code session"),
                 cjb.mos.widget.WidgetAction(widget, "terminal", "Open terminal") ]

widget = CodeWidget()
