
import cjb.uif

class Colorize(cjb.uif.Filter):

    def filterView(self, view, scene):
        view.bg = [ 0.8, 0.85, 0.8 ]
        for v in view.recursiveSubviews():
            color = None
            if isinstance(v, cjb.uif.views.Button):
                color = [ 0.7, 0.7, 0.7 ]
            if color and not v.bg:
                v.bg = color
        return view
