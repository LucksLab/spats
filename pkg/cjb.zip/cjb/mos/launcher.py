
import cjb.mos
import cjb.mos.ui


class Launcher():

    def __init__(self):
        self.mos = cjb.mos.Mos()

    def run(self):
        print "Launching mos..."
        #self.ui = cjb.mos.ui.CommandUI(self.mos)
        #self.ui.run()
        self.ui = cjb.mos.ui.MOSUI(self.mos)
        self.ui.start()
        self.ui.waitFor()

