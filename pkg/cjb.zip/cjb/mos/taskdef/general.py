
import cjb.mos.taskdef

class GeneralTask(cjb.mos.taskdef.TaskDef):
    def __init__(self):
        self.name = "General"
        self.description = "Launch applications in a workspace."

task = GeneralTask()
