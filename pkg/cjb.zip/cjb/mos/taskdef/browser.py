
import cjb.mos.app
import cjb.mos.task
import cjb.mos.taskdef
import cjb.util.osa


class BrowserTask(cjb.mos.taskdef.TaskDef):

    def __init__(self):
        self.name = "Browser"
        self.description = "Open one or more URLs in a browser session."
        self.app = cjb.mos.app.chrome()

    def startWithTask(self, task):
        self.app.launch(task)
        self.app.showUrls(task.getConfig("urls", [ "http://www.google.com" ]))
        self.app.bringToFront(task)

    def stopWithTask(self, task):
        self.app.closeWindows()
        self.app.terminate(task)

    def actions(self, task):
        return [ cjb.mos.task.TaskAction("saveUrls", "Save URL state") ]

    def saveUrls(self, task):
        urls = cjb.util.osa.getWindowUrls(self.app.appName)
        print urls
        task.setConfig("urls", urls)


task = BrowserTask()

