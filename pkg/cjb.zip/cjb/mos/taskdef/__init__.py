
import importlib
import pkgutil
import cjb.mos.taskdef


class TaskDef():

    def __init__(self):
        self.name = None
        self.description = None

    @property
    def displayName(self):
        return self.name

    def startWithTask(self, task):
        raise

    def stopWithTask(self, task):
        raise

    def actions(self, task):
        return []

def taskdefs():
    defs = []
    for loader, name, ispkg in pkgutil.walk_packages(cjb.mos.taskdef.__path__):
        defs.append(importlib.import_module('cjb.mos.taskdef.' + name).task)
    return defs
