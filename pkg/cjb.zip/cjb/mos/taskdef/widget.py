
import cjb.mos.taskdef

class WidgetTask(cjb.mos.taskdef.TaskDef):

    def __init__(self):
        self.name = "Widget"
        self.description = "Launch a widget-based task."

    def startWithTask(self, task):
        pass

    def stopWithTask(self, task):
        pass

task = WidgetTask()
