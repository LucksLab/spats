
import json
import os

import cjb.util


class Task():

    def __init__(self, mos):
        self.mos = mos
        self.taskdef = None
        self.identifier = None
        self.applications = []
        self.workspacePath = None
        self.parameters = {}
        self.running = False

    @property
    def displayName(self):
        return self.name

    def create(self, identifier, taskdef):
        self.identifier = identifier
        self.taskdef = taskdef
        self.name = taskdef.name + " Task"
        self.save()

    def configPath(self):
        if not self.workspacePath:
            self.workspacePath = os.path.join(self.mos.taskDir, self.identifier)
        return os.path.join(self.workspacePath, 'task.json')

    def load(self, identifier):
        self.identifier = identifier
        info = cjb.util.jsonAtPath(self.configPath())
        self.taskdef = self.mos.taskdefWithName(info["taskdef"])
        self.name = info.get("name", self.taskdef.name + " Task")
        self.parameters = info.get("params", {})

    def save(self):
        info = { "taskdef" : self.taskdef.name, "name" : self.name, "params" : self.parameters }
        path = self.configPath()
        if not os.path.exists(os.path.dirname(path)):
            os.mkdir(os.path.dirname(path))
        cjb.util.writeJsonToPath(info, path, pretty=True)

    def setConfig(self, key, value):
        self.parameters[key] = value
        self.save()

    def getConfig(self, key, default = None):
        return self.parameters.get(key, default)

    def start(self):
        assert self.identifier and not self.running
        self.running = True
        self.taskdef.startWithTask(self)

    def stop(self):
        self.running = False
        self.taskdef.stopWithTask(self)

    def deleteTask(self):
        self.stop()
        self.mos.deleteTask(self)

    def actions(self):
        return self.taskdef.actions(self) + self.defaultActions()

    def defaultActions(self):
        return [
            TaskAction("rename", "Rename this task"),
            TaskAction("template", "Make a template from this task"),
            TaskAction("deleteTask", "Permanently remove the current task"),
            TaskAction("stop", "End the current task"),
        ]

    def executeAction(self, action, param = None):
        print "execute: " + str(action)
        handler = getattr(self, action, None)
        if not handler:
            handler = getattr(self.taskdef, action)
        cjb.util.dispatchToHandler(handler, [self, param])

    def rename(self, task, param):
        self.name = param
        self.save()

    def template(self, task):
        pass


class TaskAction(object):

    def __init__(self, identifier, description):
        self.identifier = identifier
        self.description = description

    @property
    def displayName(self):
        return self.description

