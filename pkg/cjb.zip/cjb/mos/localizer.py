
import cjb.uif

strings = {
    'existingTask' : 'Existing Task',
    'home' : 'Home',
    'newTask' : 'New Task',
}

class Localizer(cjb.uif.Localizer):

    def __init__(self):
        cjb.uif.Localizer.__init__(self)
        self.addStringDictionary(strings)
