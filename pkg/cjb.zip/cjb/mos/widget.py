
import os

import cjb.mos.app
import cjb.mos.task
import cjb.mos.taskdef
import cjb.mos.widgets
import cjb.util


class Task(cjb.mos.task.Task):

    def __init__(self, mos):
        cjb.mos.task.Task.__init__(self, mos)
        self.widgets = []

    def widgetDefs(self):
        return availableWidgets()

    def saveWidgets(self):
        self.setConfig("widgets", [ w.infoDictionary() for w in self.widgets ])

    def start(self):
        cjb.mos.task.Task.start(self)
        self.widgets = [ Widget(self, info) for info in self.getConfig("widgets", []) ]

    def stop(self):
        for w in self.widgets:
            w.stop()
        cjb.mos.task.Task.stop(self)

    def actions(self):
        widgets = []
        if self.taskdef.name == "Widget":
            widgets.append(cjb.mos.task.TaskAction("newWidget", "New Widget"))
        return widgets + cjb.mos.task.Task.actions(self)

    def newWidget(self, widgetdef):
        widget = Widget(self)
        widget.widgetdef = widgetdef
        widget.name = widgetdef.name + " Widget"
        widget.identifier = self.newWidgetIdentifier()
        self.widgets.append(widget)
        self.saveWidgets()
        return widget

    def newWidgetIdentifier(self):
        wid = self.getConfig("nextWidgetId", 1)
        self.setConfig("nextWidgetId", 1 + wid)
        return wid

    def removeWidget(self, widget):
        self.widgets.remove(widget)
        self.saveWidgets()


class Widget(object):

    def __init__(self, task, info = None):
        self.task = task
        self.identifier = None
        self.name = None
        self.widgetdef = None
        self.state = {}
        if info:
            self.load(info)

    @property
    def displayName(self):
        return self.name

    def load(self, info):
        self.identifier = info['identifier']
        self.name = info['name']
        self.widgetdef = widgetWithId(info['widget'])

    def infoDictionary(self):
        return { 'identifier' : self.identifier,
                 'name' : self.name,
                 'widget' : self.widgetdef.identifier }

    def setConfig(self, key, value):
        self.task.setConfig("w_{}_{}".format(self.identifier, key), value)

    def getConfig(self, key, default = None):
        return self.task.getConfig("w_{}_{}".format(self.identifier, key), default)

    def actions(self):
        return self.widgetdef.actions(self) + self.defaultActions()

    def defaultActions(self):
        return [
            WidgetAction(self, "rename", "Rename this widget"),
            WidgetAction(self, "remove", "Remove this widget"),
        ]

    def executeAction(self, action, param = None):
        print "wexecute: " + str(action.identifier)
        handler = getattr(self, action.identifier, None)
        if not handler:
            handler = getattr(self.widgetdef, action.identifier)
        cjb.util.dispatchToHandler(handler, [self, param])

    def stop(self):
        self.widgetdef.stop(self)

    def rename(self, widget, param):
        self.name = param
        self.task.saveWidgets()

    def remove(self, widget):
        self.widgetdef.remove(self)
        self.task.removeWidget(self)


class WidgetAction(object):

    def __init__(self, widget, identifier, description):
        self.widget = widget
        self.identifier = identifier
        self.description = description

    @property
    def displayName(self):
        return self.description


class WidgetDef(object):

    def __init__(self):
        self.identifier = None
        self.name = None
        self.description = None

    @property
    def displayName(self):
        return self.name

    def actions(self, widget):
        return []

    def stop(self, widget):
        pass

    def remove(self, widget):
        pass

def availableWidgets():
    return cjb.mos.widgets.widgets()

def widgetWithId(identifier):
    return { w.identifier : w  for w in availableWidgets() }[identifier]

