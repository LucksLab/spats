
def parentSize(model):
    parentFrame = model["parent"]["f"]
    return parentFrame[2], parentFrame[3], parentFrame


appModel = '''
c app
 @bg 0.8 0.9 0.8
'''

homeModel = '''
c home
 @bg 0.8 0.9 0.8
 c options
  button existingTask
    @text Work on an existing task
    @bg 1 0.4 0.4
  button newTask
    @text Start a new task
    @bg 0.4 0.4 1
'''
def layout_home(model, home):
    width, height, parentFrame = parentSize(home)
    home["f"] = parentFrame
    model.viewWithKey("options")["f"] = [ 0.5 * (width - 500), 0.5 * (height - 100), 500, 100 ]
    model.viewWithKey("existingTask")["f"] = [ 20, 20, 220, 60 ]
    model.viewWithKey("newTask")["f"] = [ 260, 20, 220, 60 ]

taskTypeModel = '''
c chooseTaskType
 @bg 0.8 0.9 0.8
 label taskTypePrompt
   @text Choose Task Type:
   @fontSize 24
 button backHome
   @text Home
   @bg 1 0.4 0.4
 scrollView taskTypes
'''

taskDefModel = '''
c taskDef
 @bg 0.7 0.7 0.9
 @click
 label name
  @fontSize 20
 label desc
  @fontSize 14
'''

def layout_taskType(model, chooseTaskType):
    width, height, parentFrame = parentSize(chooseTaskType)
    chooseTaskType["f"] = parentFrame
    model.viewWithKey("taskTypePrompt")["f"] = [ 20, 20, width - 100, 36 ]
    model.viewWithKey("backHome")["f"] = [ width - 90, 20, 70, 36 ]
    tasks = model.viewWithKey("taskTypes")
    tasks["f"] = [ 20, 64, width - 40, height - 84 ]
    taskWidth, taskHeight, spacing = (0.5 * width, 100, 20)
    cur = spacing
    for task in tasks["children"]:
        task["f"] = [ 0.5 * (width - taskWidth), cur, taskWidth, taskHeight ]
        task["children"][0]["f"] = [20, 20, taskWidth - 40, 36]
        task["children"][1]["f"] = [20, 60, taskWidth - 40, 28]
        cur += (taskHeight + spacing)

chooseTaskModel = '''
c chooseTask
 @bg 0.8 0.9 0.8
 label taskPrompt
   @text Select Task:
   @fontSize 24
 button backHome
   @text Home
   @bg 1 0.4 0.4
 scrollView tasks
'''

taskModel = '''
c task
 @bg 0.7 0.7 0.9
 @click
 label name
  @fontSize 20
 label desc
  @fontSize 14
'''

def layout_chooseTask(model, chooseTask):
    width, height, parentFrame = parentSize(chooseTask)
    chooseTask["f"] = parentFrame
    model.viewWithKey("taskPrompt")["f"] = [ 20, 20, width - 100, 36 ]
    model.viewWithKey("backHome")["f"] = [ width - 90, 20, 70, 36 ]
    tasks = model.viewWithKey("tasks")
    tasks["f"] = [ 20, 64, width - 40, height - 84 ]
    taskWidth, taskHeight, spacing = (0.5 * width, 100, 20)
    cur = spacing
    for task in tasks["children"]:
        task["f"] = [ 0.5 * (width - taskWidth), cur, taskWidth, taskHeight ]
        task["children"][0]["f"] = [20, 20, taskWidth - 40, 36]
        task["children"][1]["f"] = [20, 60, taskWidth - 40, 28]
        cur += (taskHeight + spacing)

taskActionModel = '''
button action
  @text TODO
  @bg 0.4 1 0.4
'''

taskUIModel = '''
c runningTask
 @bg 0.8 0.9 0.8
 c actions
'''
def layout_taskUI(model, runningTask):
    width, height, parentFrame = parentSize(runningTask)
    runningTask["f"] = parentFrame
    actions = model.viewWithKey("actions")
    actions["f"] = [ 0.5 * (width - 500), 100, 500, height - 100 ]
    actionWidth, actionHeight, spacing = (0.5 * width, 40, 20)
    cur = spacing
    for action in actions["children"]:
        action["f"] = [ 0.5 * (width - actionWidth), cur, actionWidth, actionHeight ]
        cur += (actionHeight + spacing)

renameModel = '''
textField rename
'''
def layout_rename(model, rename):
    width, height, parentFrame = parentSize(rename)
    rename["f"] = [ 0, 0, width, height ]
