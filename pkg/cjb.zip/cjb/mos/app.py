
import os
import shutil
import signal
import subprocess
import time

import cjb.util.osa


class Application():

    def __init__(self, exe=None, app=None):
        self.executablePath = exe
        self.appName = app
        self.pid = None

    def launch(self, task):
        if self.appName:
            cjb.util.osa.launchApp(self.appName)
        else:
            subprocess.check_call([ "open",
                                    "-n",  # Open a new instance of the application(s) even if one is already running.
                                    "-F",  # Opens the application "fresh," that is, without restoring windows.
                                    self.executablePath ], cwd = task.workspacePath)

    def getPidByLastLaunchWithName(self, name):
        self.pid = int(subprocess.check_output([ "lastpid", name ]))
        print "self.pid = {}".format(self.pid)

    def bringToFront(self, task):
        cjb.util.osa.bringToFront(self.appName)

    def terminate(self, task):
        if self.appName:
            cjb.util.osa.quitApp(self.appName)
        else:
            raise

class BrowserApp(Application):

    def __init__(self, app = 'Safari'):
        Application.__init__(self, app = app)

    def showUrls(self, urls):
        cjb.util.osa.openUrlsInNewWindow(self.appName, urls)

    def closeWindows(self):
        cjb.util.osa.closeWindows(self.appName)

    def terminate(self, task):
        self.closeWindows()
        Application.terminate(self, task)


class EmacsApp(Application):

    def __init__(self, initFile = '~/.uif.emacs', useDesktop = False, geometry = '150x35'):
        Application.__init__(self, exe = '/Applications/Emacs.app/Contents/MacOS/Emacs')
        self.initFile = initFile
        self.useDesktop = useDesktop
        self.geometry = geometry
        self.fileToEdit = None
        self.lineNumber = None

    def launch(self, task):
        args = [ self.executablePath, '--geometry', self.geometry ]
        if not self.useDesktop:
            args.append('--no-desktop')
        if self.initFile:
            args.append('--load')
            args.append(self.initFile)
        if self.fileToEdit:
            if self.lineNumber:
                args.append('+{}'.format(self.lineNumber + 1))
            args.append(self.fileToEdit)
        self.popen = subprocess.Popen(args, cwd = task.workspacePath)

    def isRunning(self):
        return (self.popen.poll() is None)

    def terminate(self, task):
        if self.isRunning():
            try:
                cjb.util.osa.quitApp('Emacs')
            except:
                self.popen.kill()

g_taskbash = '''
#!/bin/bash
export TASKDIR="{}"
export HISTFILE="$TASKDIR/mosterm.history"
alias tcd="cd $TASKDIR"
cd "$TASKDIR"

#  add any extra aliases/etc here...

echo "Task: {} ($TASKDIR)"
'''

class TerminalApp(Application):

    def __init__(self, initFile = '~/mos/etc/mosterm.terminal'):
        Application.__init__(self, exe = '/Applications/Utilities/Terminal.app/Contents/MacOS/Terminal')
        self.initFile = os.path.expanduser(initFile)
        self.pid = None

    def launch(self, task):
        if self.isRunning():
            return
        baseDir = os.path.expanduser(task.workspacePath)
        histpath = os.path.join(baseDir, "mosterm.history")
        if not os.path.exists(histpath):
            cjb.util.writeDataToFileAtPath('cd {}]\n'.format(baseDir), histpath)
        taskbashrc = os.path.join(baseDir, "task.bashrc")
        if not os.path.exists(taskbashrc):
            cjb.util.writeDataToFileAtPath(g_taskbash.format(baseDir, task.name), taskbashrc)
        sesspath = os.path.join(task.mos.workDir(), "session.bashrc")
        cjb.util.writeDataToFileAtPath('#!/bin/bash\n. {}\n'.format(taskbashrc), sesspath)

        subprocess.check_call([ 'open', '-n', '-F', self.initFile ])
        self.getPidByLastLaunchWithName("Terminal")
        # doesn't seem to work if we remove the file...
        #os.remove(sesspath)

    def isRunning(self):
        return (self.pid is not None)

    def terminate(self, task):
        if self.isRunning():
            try:
                os.kill(self.pid, signal.SIGHUP)
            except:
                print "Kill failed for {}?".format(self.pid)
            self.pid = None

def safari():
    return BrowserApp(app = 'Safari')

def chrome():
    return BrowserApp(app = 'Google Chrome')

def emacs(**kwargs):
    return EmacsApp(**kwargs)

def terminal():
    return TerminalApp()

def showDocument(task, pathToDocument):
    subprocess.check_call([ "open", pathToDocument ], cwd = task.workspacePath)

def launchApp(task, pathToApp):
    subprocess.check_call([ "open", "-n", "-F", pathToApp ], cwd = task.workspacePath)
