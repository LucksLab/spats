
import cjb
import cjb.uif
import cjb.mos.colorize
import cjb.mos.localizer
import cjb.mos.scenes


class MOSUI(cjb.uif.UIServer):

    def __init__(self, mos):
        self.mos = mos
        self.config = mos.config["ui"]
        cjb.uif.UIServer.__init__(self, self.config["host"], int(self.config["port"]), self.config["portfile"])
        self.muck = mos.muck
        self.runningTask = None
        self.addFilter(cjb.mos.colorize.Colorize())
        self.addFilter(cjb.mos.localizer.Localizer())

    def home(self, message = None):
        self.setScene(cjb.mos.scenes.Home(self))

    def startTask(self, task):
        self.runningTask = task
        task.start()
        self.setScene(cjb.mos.scenes.Task(self, task))

    def taskFinished(self):
        self.runningTask = None
        self.home()
