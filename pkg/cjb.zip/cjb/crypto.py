
import base64

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric import rsa

import cjb.util


def createPrivateKey(key_size = 2048):
    pk = PrivateKey()
    pk.generate(key_size)
    return pk

def loadPrivateKey(path):
    pk = PrivateKey()
    pk.load(path)
    return pk

def loadPublicKey(path):
    pk = PublicKey()
    pk.load(path)
    return pk

def sha256(data, base64Encode = False):
    digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
    digest.update(data)
    sha = digest.finalize() 
    if base64Encode:
        sha = base64.b64encode(sha)
    return sha


class PublicKey(object):

    def __init__(self, publicKey = None):
        self.publicKey = publicKey

    def verifySignature(self, signature, message):
        verifier = self.publicKey.verifier(base64.b64decode(signature), _signaturePadding(), _signatureHash())
        verifier.update(message)
        verifier.verify()

    def save(self, path):
        pem = self.publicKey.public_bytes(encoding = serialization.Encoding.PEM,
                                          format = serialization.PublicFormat.SubjectPublicKeyInfo)
        cjb.util.writeDataToFileAtPath(pem, path)

    def load(self, path):
        if self.publicKey:
            raise Exception("key already exists")
        pem = cjb.util.dataWithFileAtPath(path)
        self.publicKey = serialization.load_pem_public_key(pem, backend = default_backend())

    def encrypt(self, message):
        return base64.b64encode(self.publicKey.encrypt(message, _encryptionPadding()))


class PrivateKey(object):

    def __init__(self):
        self.key = None
        self.public = None

    def generate(self, key_size):
        if self.key:
            raise Exception("key already exists")
        self.key = rsa.generate_private_key(public_exponent = 65537, key_size = key_size, backend = default_backend())

    def save(self, path):
        pem = self.key.private_bytes(encoding = serialization.Encoding.PEM,
                                     format = serialization.PrivateFormat.PKCS8,
                                     encryption_algorithm = serialization.NoEncryption())
        cjb.util.writeDataToFileAtPath(pem, path)

    def load(self, path):
        if self.key:
            raise Exception("key already exists")
        pem = cjb.util.dataWithFileAtPath(path)
        self.key = serialization.load_pem_private_key(pem, password = None, backend = default_backend())

    def sign(self, message):
        signer = self.key.signer(_signaturePadding(), _signatureHash())
        signer.update(message)
        return base64.b64encode(signer.finalize())

    def publicKey(self):
        if not self.public:
            self.public = PublicKey(self.key.public_key())
        return self.public

    def decrypt(self, ciphertext):
        return self.key.decrypt(base64.b64decode(ciphertext), _encryptionPadding())


def _signaturePadding():
    return padding.PSS(mgf = padding.MGF1(_signatureHash()), salt_length = padding.PSS.MAX_LENGTH)

def _signatureHash():
    return hashes.SHA256()

def _encryptionPadding():
    return padding.OAEP(mgf = padding.MGF1(algorithm = _encryptionHash()), algorithm = _encryptionHash(), label = None)

def _encryptionHash():
    return hashes.SHA1()

